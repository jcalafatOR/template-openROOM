<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   Open ROOM (C) 2020 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
// ***** DESCOMENTAR SIGUIENTE LÍNEA SI JQUERY NO SE CARGA ***** //
// JHtml::script(Juri::base() . 'templates/openroom/js/jquery.min.js');

?>