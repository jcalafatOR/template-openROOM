//! moment.js locale configuration

;(function (global, factory) {
   typeof exports === 'object' && typeof module !== 'undefined'
       && typeof require === 'function' ? factory(require('../moment')) :
   typeof define === 'function' && define.amd ? define(['../moment'], factory) :
   factory(global.moment)
}(this, (function (moment) { 'use strict';


    var monthsShortDot = 'Janv Févr Mars Avril Mai Juin Juil Aout Sept Oct Nov Déc'.split(' '),
        monthsShort = 'Janv Févr Mars Avril Mai Juin Juil Aout Sept Oct Nov Déc'.split(' ');

    var monthsParse = [/^Janv/i, /^Févr/i, /^Mars/i, /^Avril/i, /^Mai/i, /^Juin/i, /^Juil/i, /^Aout/i, /^Sept/i, /^Oct/i, /^Nov/i, /^Déc/i];
    var monthsRegex = /^(Janvier|Février|Mars|Avril|Mai|Juin|Juillet|Août|Septembre|Octobre|Novembre|Décembre|Janv\.?|Févr\.?|Mars\.?|Avril\.?|Mai\.?|Juin\.?|Juil\.?|Aout\.?|Sept\.?|Oct\.?|Nov\.?|Déc\.?)/i;

    var en = moment.defineLocale('fr-fr', {
        months : 'Janvier Février Mars Avril Mai Juin Juillet Août Septembre Octobre Novembre Décembre'.split(' '),
        monthsShort : function (m, format) {
            if (!m) {
                return monthsShortDot;
            } else if (/-MMM-/.test(format)) {
                return monthsShort[m.month()];
            } else {
                return monthsShortDot[m.month()];
            }
        },
        monthsRegex : monthsRegex,
        monthsShortRegex : monthsRegex,
        monthsStrictRegex : /^(Janvier|Février|Mars|Avril|Mai|Juin|Juillet|Août|Septembre|Octobre|Novembre|Décembre)/i,
        monthsShortStrictRegex : /^(Janv\.?|Févr\.?|Mars\.?|Avril\.?|Mai\.?|Juin\.?|Juil\.?|Aout\.?|Sept\.?|Oct\.?|Nov\.?|Déc\.?)/i,
        monthsParse : monthsParse,
        longMonthsParse : monthsParse,
        shortMonthsParse : monthsParse,
        weekdays : 'Dimanche Lundi Mardi Mercredi Jeudi Vendredi Samedi'.split(' '),
        weekdaysShort : 'Dim Lun Mar Mer Jeu Ven Sam'.split(' '),
        weekdaysMin : 'Di Lu Ma Me Je Ve Sa'.split(' '),
        weekdaysParseExact : true,
        longDateFormat : {
            LT : 'H:mm',
            LTS : 'H:mm:ss',
            L : 'DD/MM/YYYY',
            LL : 'D MMMM YYYY',
            LLL : 'D MMMM YYYY H:mm',
            LLLL : 'dddd, D MMMM YYYY H:mm'
        },
        calendar : {
            sameDay : '[Today at] LT',
            nextDay : '[Tomorrow at] LT',
            nextWeek : 'dddd [at] LT',
            lastDay : '[Yesterday at] LT',
            lastWeek : '[Last] dddd [at] LT',
            sameElse : 'L'
        },
        relativeTime : {
            future : 'in %s',
            past : '%s ago',
            s : 'a few seconds',
            ss : '%d seconds',
            m : 'a minute',
            mm : '%d minutes',
            h : 'an hour',
            hh : '%d hours',
            d : 'a day',
            dd : '%d days',
            M : 'a month',
            MM : '%d months',
            y : 'a year',
            yy : '%d years'
        },
        dayOfMonthOrdinalParse : /\d{1,2}(st|nd|rd|th)/,
         ordinal : function (number) {
            var b = number % 10,
                output = (~~(number % 100 / 10) === 1) ? 'th' :
                (b === 1) ? 'st' :
                (b === 2) ? 'nd' :
                (b === 3) ? 'rd' : 'th';
            return number + output;
        },
        week : {
            dow : 1, // Monday is the first day of the week.
            doy : 4  // The week that contains Jan 4th is the first week of the year.
        }
    });

    return en;

})));

/** EXTRA CONTENT **/
function be_month_short(e)
{
   var rs;
   switch(e)
   {
      case 1: rs = " Janv"; break;
      case 2: rs = " Févr"; break;
      case 3: rs = " Mars"; break;
      case 4: rs = " Avril"; break;
      case 5: rs = " Mai"; break;
      case 6: rs = " Juin"; break;
      case 7: rs = " Juil"; break;
      case 8: rs = " Aout"; break;
      case 9: rs = " Sept"; break;
      case 10: rs = " Oct"; break;
      case 11: rs = " Nov"; break;
      case 12: rs = " Déc"; break;
   }
   return rs;
}

function be_month_long(e)
{
   var rs;
   switch(e)
   {
      case 1: rs = " Janvier"; break;
      case 2: rs = " Février"; break;
      case 3: rs = " Mars"; break;
      case 4: rs = " Avril"; break;
      case 5: rs = " Mai"; break;
      case 6: rs = " Juin"; break;
      case 7: rs = " Juillet"; break;
      case 8: rs = " Août"; break;
      case 9: rs = " Septembre"; break;
      case 10: rs = " Octobre"; break;
      case 11: rs = " Novembre"; break;
      case 12: rs = " Décembre"; break;
   }
   return rs;
}

function be_day_short(e)
{
   var rs;
   switch(e)
   {
      case 1: rs = "Lu"; break;
      case 2: rs = "Ma"; break;
      case 3: rs = "Me"; break;
      case 4: rs = "Je"; break;
      case 5: rs = "Ve"; break;
      case 6: rs = "Sa"; break;
      case 7: rs = "Di"; break;
   }
   return rs;
}

function be_day_long(e)
{
   var rs;
   switch(e)
   {
      case 1: rs = "Lundi"; break;
      case 2: rs = "Mardi"; break;
      case 3: rs = "Mercredi"; break;
      case 4: rs = "Jeudi"; break;
      case 5: rs = "Vendredi"; break;
      case 6: rs = "Samedi"; break;
      case 7: rs = "Dimanche"; break;
   }
   return rs;
}

function be_search_text(e)
{
   var rs;
   switch(e)
   {
      case "0": rs = "Any Hotel"; break;
      case "1": rs = "Alojamiento"; break;
      case "2": rs = "Entrée"; break;
      case "3": rs = "Sortie"; break;
      case "4": rs = "Chambres"; break;
      case "4_1": rs = "Chambre"; break;
      case "4_2": rs = "Adultes"; break;
      case "4_3": rs = "Enfants"; break;
      case "4_3_1": rs = "Age"; break;
      case "5": rs = "Sélectionner"; break;
      case "6": rs = "Code promo"; break;
      case "7": rs = "My bookings"; break;
      case "8": rs = "Réserver"; break;
      case "9": rs = "Code promo"; break;
      case "10": rs = "P ex: MAJVR"; break;
      case "11": rs = "Select dates"; break;
      case "12": rs = "Accept"; break;
      case "error_1": rs = "En remplissant un champ est manquant, s'il vous plaît revisadlo"; break;
   }
   return rs;
}